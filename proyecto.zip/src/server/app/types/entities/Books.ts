export interface Book {
  id: string;
  title: string;
  author: string;
  quantity: number;
  publishedAt: string;
}
