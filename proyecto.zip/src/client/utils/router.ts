export const ROUTES = {
    ADMIN_BOOKS_PAGE: "/books/admin",
    LOGIN: "/auth/login"
}